﻿using System;
using System.Collections.Generic;

namespace Ind_Q_3
{
	public static class GraphQuestExtension
	{
		public static List<int> FindEulerCycle(this Graph graph)
		{
			// Проверка существования цикла
			string errorString = "";
			for (int v1 = 0; v1 < graph.Size; ++v1)
			{
				int degree = 0;
				for (int v2 = 0; v2 < graph.Size; ++v2)
					if (graph.Data[v1, v2])
						degree += 1;

				if (degree % 2 == 1)
					errorString += $"{v1}, ";
			}

			if (errorString != "")
				throw new Exception($"Вершины {errorString} имеют нечетную степень! Поэтому в графе нет эйлерова цикла");

			List<int> cycle = new List<int>();
			Graph workGraph = new Graph(graph.Data);

			void find(int currentVertex)
			{
				for (int v = 0; v < graph.Size; ++v)
					if (workGraph.Data[currentVertex, v])
					{
						workGraph.DeleteEdge(currentVertex, v);
						find(v);
					}
				cycle.Add(currentVertex + 1); // Сдвиг, так как считаем в выводе вершины с 1
			}

			find(0);

			return cycle;
		}
	}
}
