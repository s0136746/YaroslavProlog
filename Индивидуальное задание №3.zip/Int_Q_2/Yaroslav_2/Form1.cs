﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Ind_Q_3
{
	public partial class Form1 : Form
	{
		protected Graph m_graph;
		protected int m_standartHeight;

		public Form1()
		{
			InitializeComponent();

			MatrixLoadedTextBox.Text = "Тут будет загруженная матрица. Или просто     \r\n";
			MatrixLoadedTextBox.Text += "скопируйте ее сюда. После копирования нажмите \r\n";
			MatrixLoadedTextBox.Text += "на кнопку \"Подтвердить матрицу\" для ее      \r\n";
			MatrixLoadedTextBox.Text += "обработки.                                    \r\n";
			MatrixLoadedTextBox.Text += "Если матрица не помещается в бокс - его можно \r\n";
			MatrixLoadedTextBox.Text += "спокно растягивать!                           \r\n";
			MatrixLoadedTextBox.Text += "Из условий задачи предполагается, что граф    \r\n";
			MatrixLoadedTextBox.Text += "связный!                                      \r\n";

			m_standartHeight = Height;
		}

		private void LoadGraphButton_Click(object sender, EventArgs e)
		{
			FileDialog fileDialog = new OpenFileDialog();
			var res = fileDialog.ShowDialog();
			if (res == DialogResult.OK)
			{
				try
				{
					m_graph = Graph.LoadFromFile(fileDialog.FileName);
				}

				catch (Exception exp)
				{
					MessageBox.Show($"Ошибка!\n{exp.Message}");
					return;
				}

				MatrixLoadedTextBox.Text = m_graph.ToString();
			}
		}

		private void FindCycle_Click(object sender, EventArgs e)
		{
			/* Проверка ввода */
			if (m_graph == null)
			{
				MessageBox.Show("Введите или загрузите граф!");
				return;
			}

			List<int> cycle;
			try
			{
				cycle = m_graph.FindEulerCycle();
			}

			catch (Exception exp)
			{
				MessageBox.Show($"Ошибка!\n{exp.Message}");
				return;
			}

			StringBuilder builder = new StringBuilder("Эйлеров цикл: ");
			foreach (int i in cycle)
				builder.Append($"{i} -> ");
			builder.Remove(builder.Length - 1 - 3, 3); // Удаляет "-> " в конце
			builder.Append(".");
			MessageBox.Show(builder.ToString());
		}

		private void AcceptMatrix_Click(object sender, EventArgs e)
		{
			try
			{
				m_graph = Graph.LoadFromString(MatrixLoadedTextBox.Text);
			}

			catch (Exception exp)
			{
				MessageBox.Show($"Ошибка!\n{exp.Message}");
				return;
			}

			MatrixLoadedTextBox.Text = m_graph.ToString();
		}
	}
}
