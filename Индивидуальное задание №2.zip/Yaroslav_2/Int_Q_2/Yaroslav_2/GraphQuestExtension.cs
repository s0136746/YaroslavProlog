﻿using System;

namespace Ind_Q_2
{
	public static class GraphQuestExtension
	{
		public static bool IsConnected(this Graph graph)
		{
			// Флаги того, что мы посещали вершину
			bool[] isChecked = new bool[graph.Size];
			for (int i = 0; i < isChecked.Length; ++i)
				isChecked[i] = false;

			// Обходом в глубину пытаемся попасть во все вершины графа.
			void DFS(int vertex)
			{
				if (isChecked[vertex])
					return;

				isChecked[vertex] = true;
				for (int i = 0; i < graph.Size; ++i)
					if (graph.Data[vertex, i])
						DFS(i);
			}

			DFS(0);

			// Если не посетило хотя бы 1 вершину - граф не является связным
			for (int i = 0; i < isChecked.Length; ++i)
				if (!isChecked[i])
					return false;

			return true;
		}
	}
}
