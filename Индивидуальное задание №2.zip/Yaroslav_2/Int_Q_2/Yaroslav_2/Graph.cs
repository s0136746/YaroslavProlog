﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

/* Класс графа. Общий для всех заданий - максимум, будут добавлены
 * некоторые новые методы, которых недоставало для данной задачи.
 * */

namespace Ind_Q_2
{
	public partial class Graph
	{
		protected bool[,] m_matrix;
		protected int m_size;

		public Graph()
		{
			m_size = 0;
			m_matrix = new bool[0, 0];
		}

		public Graph(bool[,] matrix)
		{
			double sqrtSize = System.Math.Sqrt(matrix.Length);

			m_size = (int)sqrtSize;
			m_matrix = (bool[,])matrix.Clone();
		}

		/* К р а с и в а я  табличка с матрицей графа */
		public override string ToString()
		{
			StringBuilder builder = new StringBuilder();
			builder.Append("      "); // Сдвиг первой строки, чтобы была пустая ячейка
			for (int i = 0; i < Size; ++i)
				builder.Append($"{i + 1,4} |");
			builder.Append($"\r\n"); // Это переход на новую строку

			for (int i = 0; i < Size; ++i)
			{
				builder.Append($"{i + 1,4} |"); // Номер вершины

				for (int j = 0; j < Size; ++j)
					builder.Append($"{(m_matrix[i, j] ? 1 : 0),4} |"); // 1 - есть ребро, 0 - нет ребра

				builder.Append("\r\n");
			}

			return builder.ToString();
		}

		/* Сама матрица */
		public bool[,] Data
		{
			get
			{
				return m_matrix;
			}
		}

		public int Size
		{
			get
			{
				return m_size;
			}
		}

		public static Graph LoadFromFile(string file)
		{
			string readed = System.IO.File.ReadAllText(file, Encoding.UTF8);
			return LoadFromString(readed);
		}

		public static Graph LoadFromString(string input)
		{
			/* Проверка ввода и приведение его к стандартному виду. Там пробелы убрать и все такое */

			input = Regex.Replace(input, @"( |\t)+", " "); // Заменяет много пробелов и табуляций на один пробел
			input = Regex.Replace(input, @"(\r|,)", ""); // Убирает , и \r. Вроде, можно использовать [\r,]+ для того же эффекта

			// Проверка ввода

			if (input.Length == 0)
			{
				MessageBox.Show("Введите матрицу!");
				throw new Exception();
			}

			List<string> lines = new List<string>(input.Split('\n'));
			lines.RemoveAll(x => Regex.IsMatch(x, @"^\s*$")); // Удаляет пустые линии в вводе

			if (lines.Count == 0)
				throw new Exception("Введите что-то, кроме пробельных символов!");

			/* Проверки. Что делают написано в исключениях, которые выбрасываются при несоответствии */

			foreach (string line in lines)
				if (line != "" && !Regex.IsMatch(line, @"(\s*[01])+"))
					throw new Exception("Проверьте ввод матрицы! Найдены символы, отличные от пробельных, 0 и 1.");

			int firstLineSize = Regex.Matches(lines[0], @"\s*[01]").Count;
			foreach (string line in lines)
				if (line != "" && firstLineSize != Regex.Matches(line, @"\s*[01]").Count)
					throw new Exception("Проверьте ввод матрицы! Размеры строк не совпадают / введены символы, отличные от 0 и 1!");

			// Считаем непустые строки
			int emptyLines = 0;
			foreach (string line in lines)
				if (line == "")
					emptyLines++;
			int onlyMatrixSize = lines.Count - emptyLines;

			// Количество непустых строк должно быть равно длине данных строк
			if (firstLineSize != onlyMatrixSize)
				throw new Exception("Проверьте ввод матрицы! Матрица должна быть квадратной!");

			// Ура, вроде матрица введена верно, скорее всего! Парсим ее
			// Текст сейчас примерно такой:
			// 0 1 0
			// 1 0 0
			// 1 1 0
			// т е без мусора типа запятых и лишних пробелов

			bool[,] graphMatrix = new bool[onlyMatrixSize, onlyMatrixSize];

			int i = 0; // Зачем я сую туда длякаждые
			int j = 0; // просто зочем

			foreach (string line in lines) // чекаем все строки
			{
				// Удаляем пробелы в начале и в конце. На всякий случай
				foreach (string n in line.Trim().Split(' ')) // и разбиваем каждую строку по символам
				{
					graphMatrix[i, j] = (n == "1" && i != j); // если 1 - записываем это в таблицу
					j++;
				}

				i++;
				j = 0;
			}

			return new Graph(graphMatrix);
		}
	}
}
