﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Ind_Q_1
{
	public static class GraphQuestExtension
	{
		public static int[] ComputePruferCode(this Graph graph)
		{
			// Сам код на вывод
			int[] code = new int[graph.Size - 2];

			// "Удаленные вершины"
			bool[] deleted = new bool[graph.Size];
			for (int i = 0; i < graph.Size; ++i)
				deleted[i] = false;

			// Проходим по n-2 вершинам
			for (int n = 0; n < graph.Size - 2; ++n)
			{
				bool findFlag = false; // В C# лучше избегать break
				for (int i = 0; i < graph.Size && !findFlag; ++i)
				{
					// Скипаем удаленные вершины. Тут и во всех ифах ниже
					if (deleted[i])
						continue;

					// Степень вершины. У всех листов она 1
					int degree = 0;
					for (int j = 0; j < graph.Size; ++j)
						if (!deleted[j] && graph.Data[i, j]) // Считаем кол-во 1 у неудаленных вершин в данной строки
							degree++;

					// Ура, нашли лист! И этот лист - минимальный, так как попался первым
					if (degree == 1)
					{
						deleted[i] = true;
						findFlag = true;

						// Ищем вершину, из которой выходит данный лист
						for (int k = 0; k < graph.Size && code[n] == 0; ++k)
							if (!deleted[k] && graph.Data[i, k])
								code[n] = k + 1; // Добавляем ее в код. Не забываем о счете вершин с 1
					}
				}
			}

			return code;
		}
	}
}
