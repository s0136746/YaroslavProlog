﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ind_Q_1
{
	public partial class Form1 : Form
	{
		protected Graph m_graph;

		public Form1()
		{
			InitializeComponent();

			// Записываем начальное сообщение в текстбокс
			MatrixLoadedTextBox.Text =  "Тут будет загруженная матрица. Или просто     \r\n";
			MatrixLoadedTextBox.Text += "скопируйте ее сюда. После копирования нажмите \r\n";
			MatrixLoadedTextBox.Text += "на кнопку \"Подтвердить матрицу\" для ее      \r\n";
			MatrixLoadedTextBox.Text += "обработки.                                    \r\n";
			MatrixLoadedTextBox.Text += "Если матрица не помещается в бокс - его можно \r\n";
			MatrixLoadedTextBox.Text += "спокойно растягивать!                         \r\n";
		}

		private void LoadGraphButton_Click(object sender, EventArgs e)
		{
			// Выбиарем файл в файл диалоге
			FileDialog fileDialog = new OpenFileDialog();
			var res = fileDialog.ShowDialog();
			if (res == DialogResult.OK)
			{
				try // Пытаемся распарсить граф. Ловим ошибки
				{
					m_graph = Graph.LoadFromFile(fileDialog.FileName);
				}

				catch (Exception exp) // Если вышла ошибка во время парсинга - выводим
				{
					MessageBox.Show($"Ошибка!\n{exp.Message}");
					return;
				}

				MatrixLoadedTextBox.Text = m_graph.ToString();
			}
		}

		private void ComputePruferCode_Click(object sender, EventArgs e)
		{
			/* Проверка ввода */
			if (m_graph == null) // Граф изначально null. Если остался null - его еще не вводили
			{
				MessageBox.Show("Введите или загрузите граф!");
				return;
			}

			if (m_graph.Size < 2) // Менее двух вершин не имеют смысла - код Прюфера начинается от 3
			{
				MessageBox.Show("В графе должно быть не менее 3 вершин!");
				return;
			}

			/* Строим вывод */
			StringBuilder builder = new StringBuilder("Дерево закодировано в следующий код: ");
			foreach (int i in GraphQuestExtension.ComputePruferCode(m_graph))
				builder.Append($"{i} ");
			MessageBox.Show(builder.ToString());
		}

		private void AcceptMatrix_Click(object sender, EventArgs e)
		{
			try // Аналогично - проверяем ввод, выводим ошибки. Ничем не отличается от ввода с файла.
			{
				m_graph = Graph.LoadFromString(MatrixLoadedTextBox.Text);
			}

			catch (Exception exp)
			{
				MessageBox.Show($"Ошибка!\n{exp.Message}");
				return;
			}

			MatrixLoadedTextBox.Text = m_graph.ToString();
		}
	}
}
