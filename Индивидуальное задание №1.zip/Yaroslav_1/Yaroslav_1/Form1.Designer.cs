﻿namespace Ind_Q_1
{
	partial class Form1
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
			this.MatrixLoadedTextBox = new System.Windows.Forms.TextBox();
			this.LoadGraphButton = new System.Windows.Forms.Button();
			this.ComputePruferCode = new System.Windows.Forms.Button();
			this.AcceptMatrix = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// MatrixLoadedTextBox
			// 
			this.MatrixLoadedTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.MatrixLoadedTextBox.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
			this.MatrixLoadedTextBox.Location = new System.Drawing.Point(12, 12);
			this.MatrixLoadedTextBox.Multiline = true;
			this.MatrixLoadedTextBox.Name = "MatrixLoadedTextBox";
			this.MatrixLoadedTextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.MatrixLoadedTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.MatrixLoadedTextBox.Size = new System.Drawing.Size(300, 300);
			this.MatrixLoadedTextBox.TabIndex = 0;
			this.MatrixLoadedTextBox.WordWrap = false;
			// 
			// LoadGraphButton
			// 
			this.LoadGraphButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.LoadGraphButton.Location = new System.Drawing.Point(13, 319);
			this.LoadGraphButton.Name = "LoadGraphButton";
			this.LoadGraphButton.Size = new System.Drawing.Size(299, 34);
			this.LoadGraphButton.TabIndex = 1;
			this.LoadGraphButton.Text = "Загрузить матрицу";
			this.LoadGraphButton.UseVisualStyleBackColor = true;
			this.LoadGraphButton.Click += new System.EventHandler(this.LoadGraphButton_Click);
			// 
			// ComputePruferCode
			// 
			this.ComputePruferCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.ComputePruferCode.Location = new System.Drawing.Point(12, 399);
			this.ComputePruferCode.Name = "ComputePruferCode";
			this.ComputePruferCode.Size = new System.Drawing.Size(299, 34);
			this.ComputePruferCode.TabIndex = 2;
			this.ComputePruferCode.Text = "Рассчитать код Прюфера";
			this.ComputePruferCode.UseVisualStyleBackColor = true;
			this.ComputePruferCode.Click += new System.EventHandler(this.ComputePruferCode_Click);
			// 
			// AcceptMatrix
			// 
			this.AcceptMatrix.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.AcceptMatrix.Location = new System.Drawing.Point(12, 359);
			this.AcceptMatrix.Name = "AcceptMatrix";
			this.AcceptMatrix.Size = new System.Drawing.Size(299, 34);
			this.AcceptMatrix.TabIndex = 3;
			this.AcceptMatrix.Text = "Подтвердить матрицу";
			this.AcceptMatrix.UseVisualStyleBackColor = true;
			this.AcceptMatrix.Click += new System.EventHandler(this.AcceptMatrix_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(324, 441);
			this.Controls.Add(this.AcceptMatrix);
			this.Controls.Add(this.ComputePruferCode);
			this.Controls.Add(this.LoadGraphButton);
			this.Controls.Add(this.MatrixLoadedTextBox);
			this.Name = "Form1";
			this.Text = "Код Прюфера";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox MatrixLoadedTextBox;
		private System.Windows.Forms.Button LoadGraphButton;
		private System.Windows.Forms.Button ComputePruferCode;
		private System.Windows.Forms.Button AcceptMatrix;
	}
}

